CKEDITOR.plugins.setLang('video', 'en', {
  button: 'Video',
  title: 'Video properties',
  emptySrc: 'URL must not be empty.',
  controls: 'Enable controls',
  mutedLoopingAutoplay: 'Muted looping autoplay',
  preview: 'Preview',
  invalidSrc: 'URL is invalid or video is not playable.'
});
